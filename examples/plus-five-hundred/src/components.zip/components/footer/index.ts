export { Default, Minimal, Brand, Corporate } from './Footer';
export { Default as Footer } from './Footer';