export { Default, Compact } from './MarketCalenderEventDetail';
export { Default as MarketCalenderEventDetail } from './MarketCalenderEventDetail';